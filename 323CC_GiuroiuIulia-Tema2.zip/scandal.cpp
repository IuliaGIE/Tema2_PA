#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("scandal.in");
    ofstream fout("scandal.out");
    return 0;
}
